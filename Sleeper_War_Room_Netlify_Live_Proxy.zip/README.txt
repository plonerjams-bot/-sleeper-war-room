Redeploy this folder to Netlify.

Important: upload the UNZIPPED folder, not only index.html.
This version includes a Netlify Function at:
  /.netlify/functions/snapshot

That server-side function calls Sleeper and avoids Safari/browser CORS blocking.

After deployment:
1. Open /.netlify/functions/snapshot directly in Safari.
2. You should see JSON.
3. Open the homepage and tap Refresh.
