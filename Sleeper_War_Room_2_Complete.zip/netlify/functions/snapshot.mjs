const DRAFT_ID = process.env.SLEEPER_DRAFT_ID || "1362882160855379968";
const API = "https://api.sleeper.app/v1";

async function getJson(url) {
  const res = await fetch(url, { headers: { "user-agent": "SleeperWarRoom/2.0" }});
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  return await res.json();
}

export default async () => {
  try {
    const draft = await getJson(`${API}/draft/${DRAFT_ID}`);
    const picks = await getJson(`${API}/draft/${DRAFT_ID}/picks`);
    let users = [];
    if (draft.league_id) {
      try { users = await getJson(`${API}/league/${draft.league_id}/users`); } catch {}
    }

    const userMap = Object.fromEntries(users.map(u => [u.user_id, u]));
    const draftOrder = draft.draft_order || {};
    const teamsCount = Number(draft.settings?.teams || 10);
    const rounds = Number(draft.settings?.rounds || 22);
    const teams = [];

    for (let slot = 1; slot <= teamsCount; slot++) {
      const userId = Object.keys(draftOrder).find(id => Number(draftOrder[id]) === slot);
      const user = userMap[userId] || {};
      const teamPicks = picks
        .filter(p => Number(p.draft_slot) === slot)
        .sort((a,b) => Number(a.pick_no) - Number(b.pick_no))
        .map(p => {
          const m = p.metadata || {};
          return {
            pick_no: p.pick_no,
            round: p.round,
            draft_slot: p.draft_slot,
            player_id: p.player_id,
            name: `${m.first_name || ""} ${m.last_name || ""}`.trim() || p.player_id,
            position: m.position || "OTHER",
            team: m.team || null
          };
        });

      const counts = {QB:0,RB:0,WR:0,TE:0,OTHER:0};
      for (const p of teamPicks) counts[counts[p.position] !== undefined ? p.position : "OTHER"]++;

      teams.push({
        slot,
        display_name: user.display_name || user.username || `Team ${slot}`,
        user_id: userId || null,
        counts,
        picks: teamPicks
      });
    }

    const normalized = picks.slice().sort((a,b) => Number(a.pick_no)-Number(b.pick_no)).map(p => {
      const m = p.metadata || {};
      return {
        pick_no: p.pick_no,
        round: p.round,
        draft_slot: p.draft_slot,
        player_id: p.player_id,
        name: `${m.first_name || ""} ${m.last_name || ""}`.trim() || p.player_id,
        position: m.position || "OTHER",
        team: m.team || null
      };
    });

    const position_totals = {QB:0,RB:0,WR:0,TE:0,OTHER:0};
    for (const p of normalized) position_totals[position_totals[p.position] !== undefined ? p.position : "OTHER"]++;

    return new Response(JSON.stringify({
      draft: {
        draft_id: DRAFT_ID,
        status: draft.status,
        season: draft.season,
        type: draft.type,
        settings: draft.settings || {}
      },
      pick_count: picks.length,
      next_pick_no: picks.length < teamsCount * rounds ? picks.length + 1 : null,
      teams,
      picks: normalized,
      position_totals,
      refreshed_at: Math.floor(Date.now()/1000)
    }), {
      headers: {
        "content-type":"application/json",
        "cache-control":"no-store"
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({error:String(error.message || error)}), {
      status:500,
      headers:{"content-type":"application/json"}
    });
  }
};